

void systick_init(void);
void DelayMs(unsigned long t);
void systick_int(unsigned short uart_1_mgr[],unsigned short uart_2_mgr[],unsigned short uart_3_mgr[]);
void systick_int_start(void);
