#include "uart_drive.h"
#include "help_func.h"



void basic_msg(char uart, int val);
