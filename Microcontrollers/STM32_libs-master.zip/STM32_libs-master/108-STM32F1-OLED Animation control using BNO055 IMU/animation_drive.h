#include "oled_drive.h"

void center(ImgType * Img);
int IMU_motion(ImgType * Img,short new_pos[],int * right_left);
