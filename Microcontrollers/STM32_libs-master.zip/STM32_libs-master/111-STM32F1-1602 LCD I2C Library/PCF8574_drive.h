#include "i2c_drive.h"


void PCF8574_tx_byte(char i2c, char data);
